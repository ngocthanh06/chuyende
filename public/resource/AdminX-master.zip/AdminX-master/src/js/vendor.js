// Uncomment if you don't need a library
window.Choices = require('choices.js');
window.Cleave = require('cleave.js');
window.flatpickr = require('flatpickr');

// feather icons
import feather from 'feather-icons';
feather.replace();